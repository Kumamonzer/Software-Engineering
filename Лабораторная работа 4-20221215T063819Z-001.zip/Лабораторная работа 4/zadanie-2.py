import math
x = 1
y = 2
z = ((math.sin(x))**2 + (math.cos(y))**2)*2
print(z)